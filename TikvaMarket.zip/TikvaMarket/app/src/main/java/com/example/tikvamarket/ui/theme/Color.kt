package com.example.tikvamarket.ui.theme

import androidx.compose.ui.graphics.Color

// Цвета из изображения
val Night = Color(0xFF0D0A0B)
val Charcoal = Color(0xFF454955)
val Magnolia = Color(0xFFF3EFF5)
val AppleGreen = Color(0xFF72B01D)
val OfficeGreen = Color(0xFF3F7D20)